/* Formulář odznaku: přepínání ikona/text, výchozí barva a popisek podle ikony, živý náhled. */
jQuery( function ( $ ) {
	var $form = $( '#post' );
	var $text = $form.find( '[name="badge_settings[text]"]' );
	var $bg = $form.find( '[name="badge_settings[bg_color]"]' );
	var $fg = $form.find( '[name="badge_settings[text_color]"]' );
	var presetLabels = $form.find( '.fxb-pick input' ).map( function () { return $( this ).data( 'label' ); } ).get();

	function field( name ) {
		return $form.find( '[name="badge_settings[' + name + ']"]' );
	}

	function render() {
		var type = field( 'type' ).filter( ':checked' ).val();
		var position = field( 'position' ).val();
		var $badge = $( '<span class="fxb-badge"></span>' )
			.addClass( 'fxb-' + field( 'size' ).val() + ' fxb-' + field( 'shape' ).val() + ' fxb-type-' + type )
			.css( { '--fxb-bg': $bg.val(), '--fxb-fg': $fg.val() } );

		if ( type === 'icon' ) {
			$badge.attr( 'data-label', $text.val() ).append( field( 'icon' ).filter( ':checked' ).closest( '.fxb-pick' ).find( 'svg' ).clone() );
		} else {
			$badge.text( $text.val() );
		}

		$( '.fxb-only-icon' ).toggle( type === 'icon' );
		$( '.fxb-only-text' ).toggle( type === 'text' );
		$( '.fxb-stage .fxb-corner' ).attr( 'class', 'fxb-corner fxb-' + position ).empty().append( $badge );
	}

	$( '.fxb-color' ).wpColorPicker( { change: function () { setTimeout( render, 0 ); }, clear: function () { setTimeout( render, 0 ); } } );

	// Při výběru ikony se doplní její barva a popisek, ale jen pokud popisek není vlastní.
	field( 'icon' ).on( 'change', function () {
		var label = $text.val();
		if ( label === '' || presetLabels.indexOf( label ) !== -1 ) {
			$text.val( $( this ).data( 'label' ) );
			$bg.wpColorPicker( 'color', $( this ).data( 'color' ) );
		}
		render();
	} );

	$form.on( 'input change', '[name^="badge_settings"]', render );
	render();
} );
