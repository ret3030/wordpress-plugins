<?php
/** Administrace odznaků: typ příspěvku, formulář, ukládání, sloupce v seznamu a založení hotových ikon. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'init',
	function () {
		register_post_type(
			'fx-badge',
			array(
				'labels'       => array(
					'name'          => 'Odznaky',
					'singular_name' => 'Odznak',
					'menu_name'     => 'Odznaky',
					'add_new'       => 'Přidat odznak',
					'add_new_item'  => 'Přidat odznak',
					'edit_item'     => 'Upravit odznak',
					'search_items'  => 'Hledat odznaky',
					'not_found'     => 'Žádné odznaky',
				),
				'public'       => false,
				'show_ui'      => true,
				'supports'     => array( 'title' ),
				'menu_icon'    => 'dashicons-awards',
				'menu_position' => 56,
			)
		);
	}
);

/**
 * Hotové ikony se založí jako koncepty, tedy vypnuté. Stačí u nich vybrat kategorie nebo produkty
 * a zveřejnit. Přidá se jen to, co chybí, takže nové ikony v další verzi se doplní bez duplicit.
 */
add_action(
	'admin_init',
	function () {
		if ( get_option( 'fxb_seeded' ) === FXB_VERSION ) {
			return;
		}
		$existing = get_posts(
			array(
				'post_type'   => 'fx-badge',
				'post_status' => 'any',
				'numberposts' => -1,
				'meta_key'    => '_fxb_preset',
				'fields'      => 'ids',
			)
		);
		$have     = array_map( function ( $id ) { return get_post_meta( $id, '_fxb_preset', true ); }, $existing );

		foreach ( fxb_presets() as $key => $preset ) {
			if ( in_array( $key, $have, true ) ) {
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'   => 'fx-badge',
					'post_status' => 'draft',
					'post_title'  => $preset['label'],
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_fxb_preset', $key );
				update_post_meta(
					$id,
					'_badge_settings',
					fxb_clean_settings(
						array_merge(
							fxb_defaults(),
							array(
								'type'     => 'icon',
								'icon'     => $key,
								'text'     => $preset['label'],
								'bg_color' => $preset['color'],
								'position' => $preset['position'],
							)
						)
					)
				);
			}
		}
		update_option( 'fxb_seeded', FXB_VERSION );
	}
);

add_action(
	'add_meta_boxes_fx-badge',
	function () {
		add_meta_box( 'fxb_settings', 'Vzhled odznaku', 'fxb_box_settings', 'fx-badge', 'normal', 'high' );
		add_meta_box( 'fxb_scope', 'Kde se odznak zobrazí', 'fxb_box_scope', 'fx-badge', 'normal', 'default' );
		add_meta_box( 'fxb_preview', 'Náhled', 'fxb_box_preview', 'fx-badge', 'side', 'high' );
	}
);

function fxb_box_settings( WP_Post $post ) {
	wp_nonce_field( 'fxb_save', 'fxb_nonce' );

	$stored = get_post_meta( $post->ID, '_badge_settings', true );
	$s      = $stored ? fxb_clean_settings( $stored ) : fxb_defaults();

	$positions = array(
		'top-left'     => 'Vlevo nahoře',
		'top-right'    => 'Vpravo nahoře',
		'bottom-left'  => 'Vlevo dole',
		'bottom-right' => 'Vpravo dole',
	);
	$sizes     = array( 'small' => 'Malý', 'medium' => 'Střední', 'large' => 'Velký' );
	$shapes    = array( 'circle' => 'Kruh', 'rounded' => 'Zaoblený', 'rectangle' => 'Obdélník' );
	?>
	<table class="form-table fxb-form" role="presentation">
		<tr>
			<th>Typ</th>
			<td>
				<label><input type="radio" name="badge_settings[type]" value="icon" <?php checked( $s['type'], 'icon' ); ?>> Ikona</label>
				<label><input type="radio" name="badge_settings[type]" value="text" <?php checked( $s['type'], 'text' ); ?>> Text</label>
			</td>
		</tr>
		<tr class="fxb-only-icon">
			<th>Ikona</th>
			<td class="fxb-picker">
				<?php foreach ( fxb_presets() as $key => $preset ) : ?>
					<label class="fxb-pick">
						<input type="radio" name="badge_settings[icon]" value="<?php echo esc_attr( $key ); ?>" data-label="<?php echo esc_attr( $preset['label'] ); ?>" data-color="<?php echo esc_attr( $preset['color'] ); ?>" <?php checked( $s['icon'], $key ); ?>>
						<?php echo fxb_icon_svg( $key ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<span><?php echo esc_html( $preset['label'] ); ?></span>
					</label>
				<?php endforeach; ?>
			</td>
		</tr>
		<tr>
			<th>
				<span class="fxb-only-icon">Popisek při najetí myší</span>
				<span class="fxb-only-text">Text odznaku</span>
			</th>
			<td><input type="text" name="badge_settings[text]" value="<?php echo esc_attr( $s['text'] ); ?>" class="regular-text" maxlength="60"></td>
		</tr>
		<tr>
			<th>Barva pozadí</th>
			<td><input type="text" name="badge_settings[bg_color]" value="<?php echo esc_attr( $s['bg_color'] ); ?>" class="fxb-color"></td>
		</tr>
		<tr>
			<th>Barva textu a ikony</th>
			<td><input type="text" name="badge_settings[text_color]" value="<?php echo esc_attr( $s['text_color'] ); ?>" class="fxb-color"></td>
		</tr>
		<tr>
			<th>Umístění</th>
			<td>
				<select name="badge_settings[position]">
					<?php foreach ( $positions as $value => $name ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['position'], $value ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description">Více odznaků ve stejném rohu se řadí pod sebe.</p>
			</td>
		</tr>
		<tr>
			<th>Velikost a tvar</th>
			<td>
				<select name="badge_settings[size]">
					<?php foreach ( $sizes as $value => $name ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['size'], $value ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
				</select>
				<select name="badge_settings[shape]">
					<?php foreach ( $shapes as $value => $name ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['shape'], $value ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
		<tr>
			<th>Zobrazit</th>
			<td>
				<label><input type="checkbox" name="badge_settings[show_on_loop]" value="yes" <?php checked( $s['show_on_loop'], 'yes' ); ?>> Ve výpisu produktů</label><br>
				<label><input type="checkbox" name="badge_settings[show_on_single]" value="yes" <?php checked( $s['show_on_single'], 'yes' ); ?>> Na detailu produktu</label>
			</td>
		</tr>
	</table>
	<?php
}

function fxb_box_scope( WP_Post $post ) {
	$selected_cats = array_map( 'absint', (array) get_post_meta( $post->ID, '_assigned_categories', true ) );
	$selected_prod = array_filter( array_map( 'absint', (array) get_post_meta( $post->ID, '_assigned_products', true ) ) );
	$categories    = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	?>
	<p class="description">Odznak se ukáže u produktů z vybraných kategorií (včetně podkategorií) a u vybraných produktů. Odznak se zobrazuje, jen když je zveřejněný.</p>
	<p>
		<label for="fxb_categories"><strong>Kategorie</strong></label><br>
		<select id="fxb_categories" name="assigned_categories[]" class="wc-enhanced-select" multiple style="width:100%" data-placeholder="Vyberte kategorie">
			<?php foreach ( is_array( $categories ) ? $categories : array() as $term ) : ?>
				<option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( in_array( $term->term_id, $selected_cats, true ) ); ?>>
					<?php echo esc_html( str_repeat( "\u{00a0}\u{00a0}\u{00a0}", count( get_ancestors( $term->term_id, 'product_cat' ) ) ) . $term->name ); ?>
				</option>
			<?php endforeach; ?>
		</select>
	</p>
	<p>
		<label for="fxb_products"><strong>Konkrétní produkty</strong></label><br>
		<select id="fxb_products" name="assigned_products[]" class="wc-product-search" multiple style="width:100%" data-placeholder="Hledat produkt" data-action="woocommerce_json_search_products">
			<?php
			foreach ( $selected_prod as $product_id ) {
				$product = wc_get_product( $product_id );
				if ( $product ) {
					echo '<option value="' . esc_attr( $product_id ) . '" selected>' . esc_html( $product->get_formatted_name() ) . '</option>';
				}
			}
			?>
		</select>
	</p>
	<?php
}

function fxb_box_preview() {
	echo '<div class="fxb-stage"><div class="fxb-corner"></div></div>';
}

add_action(
	'save_post_fx-badge',
	function ( $post_id ) {
		if ( ! isset( $_POST['fxb_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['fxb_nonce'] ), 'fxb_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_badge_settings', fxb_clean_settings( wp_unslash( $_POST['badge_settings'] ?? array() ) ) );
		update_post_meta( $post_id, '_assigned_products', array_filter( array_map( 'absint', (array) ( $_POST['assigned_products'] ?? array() ) ) ) );
		update_post_meta( $post_id, '_assigned_categories', array_filter( array_map( 'absint', (array) ( $_POST['assigned_categories'] ?? array() ) ) ) );
		// Přechod stavu proběhl před uložením metadat, proto druhé vyprázdnění.
		fxb_flush_cache();
	}
);

add_filter(
	'manage_fx-badge_posts_columns',
	function ( array $columns ): array {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['fxb_preview'] = 'Náhled';
				$new['fxb_scope']   = 'Zobrazuje se u';
			}
		}
		return $new;
	}
);

add_action(
	'manage_fx-badge_posts_custom_column',
	function ( string $column, int $post_id ) {
		if ( 'fxb_preview' === $column ) {
			$badge = array( 'id' => $post_id, 'settings' => fxb_clean_settings( get_post_meta( $post_id, '_badge_settings', true ) ) );
			echo '<div class="fxb-corner fxb-static">' . fxb_badge_html( $badge ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			return;
		}
		if ( 'fxb_scope' !== $column ) {
			return;
		}

		$names = array();
		foreach ( array_filter( array_map( 'absint', (array) get_post_meta( $post_id, '_assigned_categories', true ) ) ) as $term_id ) {
			$term = get_term( $term_id, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$names[] = $term->name;
			}
		}
		$products = count( array_filter( (array) get_post_meta( $post_id, '_assigned_products', true ) ) );
		if ( $products ) {
			$names[] = sprintf( 'produkty: %d', $products );
		}
		echo $names ? esc_html( implode( ', ', $names ) ) : 'nikde (vyberte kategorie nebo produkty)';
	},
	10,
	2
);

add_action(
	'admin_enqueue_scripts',
	function ( string $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || 'fx-badge' !== $screen->post_type ) {
			return;
		}

		wp_enqueue_style( 'fxb-badges', FXB_URL . 'assets/css/badges.css', array(), FXB_VERSION );
		wp_enqueue_style( 'fxb-admin', FXB_URL . 'assets/css/admin.css', array( 'fxb-badges' ), FXB_VERSION );

		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_script( 'fxb-admin', FXB_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker' ), FXB_VERSION, true );
	}
);
