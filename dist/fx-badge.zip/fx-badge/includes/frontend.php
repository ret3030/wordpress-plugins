<?php
/** Výpis odznaků ve výpisu produktů a na detailu produktu. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'fxb-badges', FXB_URL . 'assets/css/badges.css', array(), FXB_VERSION );
	}
);

function fxb_print_badges( string $where ) {
	global $product;
	if ( $product instanceof WC_Product ) {
		echo fxb_corners_html( fxb_badges_for_product( $product, $where ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML je escapované při sestavení.
	}
}

add_action( 'woocommerce_before_shop_loop_item_title', function () { fxb_print_badges( 'loop' ); }, 9 );
add_action( 'woocommerce_before_single_product_summary', function () { fxb_print_badges( 'single' ); }, 9 );
