# Velrion Cache

Minimalistická náhrada SiteGround Speed Optimizeru pro cache stránek. Obecný plugin pro weby na SiteGroundu.

## Jak to funguje

Stránky cachuje **přímo server SiteGroundu** (Dynamic Cache v NGINX), ještě před spuštěním PHP a WordPressu. To je nejrychlejší možná cache a žádný PHP plugin ji nepřekoná. Plugin se stará jen o to, aby cache nikdy neukazovala zastaralý obsah: po každé změně ji smaže stejným příkazem jako SiteGround Speed Optimizer (socket Site Tools `/chroot/tmp/site-tools.sock`).

Cache se smaže po:

- zveřejnění, úpravě, stažení nebo smazání stránky, produktu, příspěvku, FAQ,
- **změně skladu** (i automaticky po objednávce, kvůli „Skladem / Vyprodáno“),
- schválení recenze nebo komentáře,
- změně kategorií, menu, přizpůsobení vzhledu, uložení v Elementoru, aktualizaci nebo (de)aktivaci pluginu,
- uložení galerie (Média → Galerie) nebo Velrion Snippets.

Víc změn v jednom požadavku (produkt s variantami, import) = jedno smazání. Ručně: tlačítko **Vymazat cache** v horní liště (administrátor, správce obchodu ji nevidí, nepotřebuje).

Košík, pokladnu, účet a přihlášené uživatele server necachuje (WooCommerce posílá hlavičky proti cache a SiteGround přeskakuje požadavky s košíkem a přihlášením).

## Nastavení na SiteGroundu

1. Site Tools → **Speed → Caching → Dynamic Cache**: zapnout pro doménu.
2. Aktivovat Velrion Cache. SiteGround Speed Optimizer nemá být aktivní současně.
3. Ověření: v anonymním okně otevřít web a v Nástrojích vývojáře → Síť u hlavního dokumentu hledat hlavičku `x-proxy-cache: HIT` (při druhém načtení).

Mimo SiteGround plugin nic nedělá (socket neexistuje), tlačítko jen ohlásí, že cache není.

## Co plugin záměrně nedělá

- Minifikaci a spojování CSS/JS: na e-shopu s Elementorem a platební bránou častý zdroj chyb, přínos je malý.
- Memcached (cache databázových dotazů): vyžaduje drop-in `object-cache.php`, případně samostatný krok.
- Optimalizaci obrázků: řeší Velrion Images.
