<?php
/**
 * Plugin Name:       Velrion Cache
 * Description:       Promazává serverovou cache SiteGroundu (Dynamic Cache) po každé změně obsahu, skladu nebo vzhledu. Tlačítko „Vymazat cache“ v horní liště.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Text Domain:       velrion-cache
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Socket Site Tools na serverech SiteGroundu; stejný používá SiteGround Speed Optimizer. */
const VELRION_CACHE_SOCKET = '/chroot/tmp/site-tools.sock';

/**
 * Smaže celou cache domény. Web je malý, takže je jednodušší a bezpečnější smazat vše,
 * než dohledávat, na kterých stránkách se změněný produkt nebo text zobrazuje.
 */
function velrion_cache_purge(): bool {
	if ( ! file_exists( VELRION_CACHE_SOCKET ) ) {
		return false; // Není SiteGround: žádná serverová cache, není co mazat.
	}

	$socket = @stream_socket_client( 'unix://' . VELRION_CACHE_SOCKET, $errno, $errstr, 5 );
	if ( ! $socket ) {
		error_log( 'Velrion Cache: socket Site Tools nedostupný: ' . $errstr );
		return false;
	}

	$request = array(
		'api'      => 'domain-all',
		'cmd'      => 'update',
		'params'   => array(
			'flush_cache' => '1',
			'id'          => str_replace( 'www.', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) ),
			'path'        => '/(.*)',
		),
		'settings' => array( 'json' => 1 ),
	);
	fwrite( $socket, wp_json_encode( $request, JSON_FORCE_OBJECT ) . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	$response = json_decode( (string) fgets( $socket, 32 * 1024 ), true );
	fclose( $socket ); // phpcs:ignore WordPress.WP.AlternativeFunctions

	if ( isset( $response['err_code'] ) ) {
		error_log( 'Velrion Cache: mazání cache selhalo: ' . ( $response['message'] ?? $response['err_code'] ) );
		return false;
	}
	return true;
}

/** Při hromadných změnách (import, uložení produktu s variantami) se cache smaže jen jednou, na konci požadavku. */
function velrion_cache_purge_later(): void {
	static $scheduled = false;
	if ( ! $scheduled ) {
		$scheduled = true;
		add_action( 'shutdown', 'velrion_cache_purge' );
	}
}

/* ------------------------------------------------------------------ */
/* Kdy mazat                                                           */
/* ------------------------------------------------------------------ */

// Obsah: zveřejnění, úprava zveřejněného, stažení nebo smazání stránky, příspěvku, produktu, FAQ.
add_action(
	'transition_post_status',
	function ( $new_status, $old_status, $post ) {
		if ( ( 'publish' === $new_status || 'publish' === $old_status ) && is_post_type_viewable( $post->post_type ) ) {
			velrion_cache_purge_later();
		}
	},
	10,
	3
);

// Sklad: „Skladem“ / „Vyprodáno“ se mění i objednávkou, bez úpravy produktu.
foreach ( array(
	'woocommerce_product_set_stock',
	'woocommerce_variation_set_stock',
	'woocommerce_product_set_stock_status',
	'woocommerce_variation_set_stock_status',
) as $hook ) {
	add_action( $hook, 'velrion_cache_purge_later' );
}

// Recenze a komentáře, jakmile jsou schválené.
add_action(
	'comment_post',
	function ( $comment_id, $approved ) {
		if ( 1 === (int) $approved ) {
			velrion_cache_purge_later();
		}
	},
	10,
	2
);
add_action( 'wp_set_comment_status', 'velrion_cache_purge_later' );

// Vzhled, menu, kategorie, Elementor, aktualizace a obsah z vlastních pluginů (galerie, snippety).
foreach ( array(
	'created_term',
	'edited_term',
	'delete_term',
	'wp_update_nav_menu',
	'customize_save_after',
	'switch_theme',
	'upgrader_process_complete',
	'activated_plugin',
	'deactivated_plugin',
	'elementor/editor/after_save',
	'elementor/core/files/clear_cache',
	'update_option_cg_galleries',
	'update_option_velrion_snippets',
) as $hook ) {
	add_action( $hook, 'velrion_cache_purge_later' );
}

/* ------------------------------------------------------------------ */
/* Tlačítko v horní liště                                              */
/* ------------------------------------------------------------------ */

add_action(
	'admin_bar_menu',
	function ( $admin_bar ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$admin_bar->add_node(
			array(
				'id'    => 'velrion-cache',
				'title' => 'Vymazat cache',
				'href'  => wp_nonce_url( admin_url( 'admin-post.php?action=velrion_cache_purge' ), 'velrion_cache_purge' ),
			)
		);
	},
	90
);

add_action(
	'admin_post_velrion_cache_purge',
	function () {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'Nemáte oprávnění.' );
		}
		check_admin_referer( 'velrion_cache_purge' );

		$message = velrion_cache_purge()
			? 'Cache webu je vymazaná.'
			: 'Cache se nepodařilo vymazat. Web neběží na SiteGroundu nebo server cache odmítl (podrobnosti v logu chyb).';
		set_transient( 'velrion_cache_notice_' . get_current_user_id(), $message, 60 );

		wp_safe_redirect( wp_get_referer() ?: admin_url() );
		exit;
	}
);

add_action(
	'admin_notices',
	function () {
		$key     = 'velrion_cache_notice_' . get_current_user_id();
		$message = get_transient( $key );
		if ( $message ) {
			delete_transient( $key );
			printf( '<div class="notice notice-info is-dismissible"><p>%s</p></div>', esc_html( $message ) );
		}
	}
);
