<?php
/**
 * Plugin Name:       Velrion Review Request
 * Description:       Po dokončení objednávky naplánuje e-mail se žádostí o recenzi koupených produktů (výchozí za 6 dní). Nastavení ve WooCommerce → Nastavení → E-maily.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Text Domain:       velrion-review-request
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const VELRION_RR_HOOK = 'velrion_review_request_send';
const VELRION_RR_META = '_velrion_review_request'; // scheduled | sent

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

add_filter(
	'woocommerce_email_classes',
	function ( $emails ) {
		require_once __DIR__ . '/includes/class-velrion-review-request-email.php';
		$emails['Velrion_Review_Request_Email'] = new Velrion_Review_Request_Email();
		return $emails;
	}
);

function velrion_rr_email(): ?WC_Email {
	return WC()->mailer()->get_emails()['Velrion_Review_Request_Email'] ?? null;
}

/** Objednávka je dokončená (odeslaná): naplánovat žádost o recenzi, každé objednávce jen jednou. */
add_action(
	'woocommerce_order_status_completed',
	function ( $order_id, $order ) {
		$email = velrion_rr_email();
		if ( ! $email || ! $email->is_enabled() || $order->get_meta( VELRION_RR_META ) ) {
			return;
		}
		$days = max( 0, (int) $email->get_option( 'days', 6 ) );
		as_schedule_single_action( time() + $days * DAY_IN_SECONDS, VELRION_RR_HOOK, array( 'order_id' => (int) $order_id ), 'velrion-review-request', true );

		$order->update_meta_data( VELRION_RR_META, 'scheduled' );
		$order->add_order_note( sprintf( 'Žádost o recenzi naplánována za %d dní.', $days ) );
		$order->save();
	},
	10,
	2
);

add_action(
	VELRION_RR_HOOK,
	function ( $order_id ) {
		$order = wc_get_order( $order_id );
		// Mezitím zrušená, vrácená nebo už obsloužená objednávka žádost nedostane.
		if ( ! $order || 'completed' !== $order->get_status() || 'sent' === $order->get_meta( VELRION_RR_META ) ) {
			return;
		}
		$email = velrion_rr_email();
		if ( ! $email || ! $email->is_enabled() ) {
			return;
		}
		$email->trigger( $order );

		$order->update_meta_data( VELRION_RR_META, 'sent' );
		$order->add_order_note( 'Žádost o recenzi odeslána zákazníkovi.' );
		$order->save();
	}
);
