<?php
/**
 * Žádost o recenzi, HTML. Šablonu jde přepsat v šabloně webu: woocommerce/emails/velrion-review-request.php.
 *
 * @var WC_Order     $order
 * @var WC_Product[] $products
 * @var string       $email_heading
 * @var string       $additional_content
 * @var WC_Email     $email
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$button_color = get_option( 'woocommerce_email_base_color', '#7f54b3' );

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<p><?php printf( 'Dobrý den %s,', esc_html( $order->get_billing_first_name() ) ); ?></p>
<p><?php printf( 'děkujeme za objednávku č. %s. Budeme rádi, když nám napíšete, jak jste spokojeni. Vaše hodnocení pomůže dalším zákazníkům s výběrem.', esc_html( $order->get_order_number() ) ); ?></p>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin:24px 0;">
	<?php foreach ( $products as $product ) : ?>
		<tr>
			<td style="padding:10px 0;border-bottom:1px solid #e5e5e5;"><?php echo esc_html( $product->get_name() ); ?></td>
			<td style="padding:10px 0;border-bottom:1px solid #e5e5e5;text-align:right;">
				<a href="<?php echo esc_url( get_permalink( $product->get_id() ) . '#reviews' ); ?>" style="display:inline-block;padding:10px 18px;background:<?php echo esc_attr( $button_color ); ?>;color:#ffffff;text-decoration:none;border-radius:3px;font-weight:bold;">Napsat hodnocení</a>
			</td>
		</tr>
	<?php endforeach; ?>
</table>

<?php
if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}

do_action( 'woocommerce_email_footer', $email );
