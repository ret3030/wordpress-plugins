<?php
/**
 * Žádost o recenzi, prostý text.
 *
 * @var WC_Order     $order
 * @var WC_Product[] $products
 * @var string       $email_heading
 * @var string       $additional_content
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo '= ' . esc_html( wp_strip_all_tags( $email_heading ) ) . " =\n\n";
printf( "Dobrý den %s,\n\n", esc_html( $order->get_billing_first_name() ) );
printf( "děkujeme za objednávku č. %s. Budeme rádi, když nám napíšete, jak jste spokojeni. Vaše hodnocení pomůže dalším zákazníkům s výběrem.\n\n", esc_html( $order->get_order_number() ) );

foreach ( $products as $product ) {
	printf( "%s\nNapsat hodnocení: %s\n\n", esc_html( $product->get_name() ), esc_url_raw( get_permalink( $product->get_id() ) . '#reviews' ) );
}

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) ) . "\n\n";
}

echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
