<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Velrion_Review_Request_Email extends WC_Email {
	public function __construct() {
		$this->id             = 'velrion_review_request';
		$this->customer_email = true;
		$this->title          = 'Žádost o recenzi';
		$this->description    = 'Odchází zákazníkovi nastavený počet dní po přepnutí objednávky na Dokončená, s odkazy na hodnocení koupených produktů.';
		$this->template_base  = dirname( __DIR__ ) . '/templates/';
		$this->template_html  = 'emails/velrion-review-request.php';
		$this->template_plain = 'emails/plain/velrion-review-request.php';
		$this->placeholders   = array(
			'{order_number}'        => '',
			'{customer_first_name}' => '',
		);

		parent::__construct();
	}

	public function get_default_subject() {
		return 'Jak jste spokojeni s nákupem z {site_title}?';
	}

	public function get_default_heading() {
		return 'Jak se vám nákup líbí?';
	}

	public function get_default_additional_content() {
		return 'Pokud cokoli není v pořádku, stačí odpovědět na tento e-mail, rádi to vyřešíme.';
	}

	public function init_form_fields() {
		parent::init_form_fields();
		$this->form_fields['days'] = array(
			'title'       => 'Odeslat po',
			'type'        => 'number',
			'description' => 'Počet dní od přepnutí objednávky na Dokončená. Platí pro nově dokončené objednávky.',
			'default'     => 6,
			'desc_tip'    => true,
		);
	}

	public function trigger( WC_Order $order ) {
		$this->setup_locale();
		$this->object                                 = $order;
		$this->recipient                              = $order->get_billing_email();
		$this->placeholders['{order_number}']         = $order->get_order_number();
		$this->placeholders['{customer_first_name}']  = $order->get_billing_first_name();
		$this->send_notification();
		$this->restore_locale();
	}

	/**
	 * Koupené produkty, které jde hodnotit: u varianty nadřazený produkt, každý jen jednou.
	 *
	 * @return WC_Product[]
	 */
	public function get_reviewable_products(): array {
		$products = array();
		foreach ( $this->object->get_items() as $item ) {
			$product = $item->get_product();
			if ( $product && $product->get_parent_id() ) {
				$product = wc_get_product( $product->get_parent_id() );
			}
			if ( $product && $product->get_reviews_allowed() ) {
				$products[ $product->get_id() ] = $product;
			}
		}
		return array_values( $products );
	}

	public function get_content_html() {
		return wc_get_template_html( $this->template_html, $this->template_args( false ), '', $this->template_base );
	}

	public function get_content_plain() {
		return wc_get_template_html( $this->template_plain, $this->template_args( true ), '', $this->template_base );
	}

	private function template_args( bool $plain ): array {
		return array(
			'order'              => $this->object,
			'products'           => $this->get_reviewable_products(),
			'email_heading'      => $this->get_heading(),
			'additional_content' => $this->get_additional_content(),
			'sent_to_admin'      => false,
			'plain_text'         => $plain,
			'email'              => $this,
		);
	}
}
