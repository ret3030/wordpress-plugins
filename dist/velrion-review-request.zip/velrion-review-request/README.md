# Velrion Review Request

Žádost o recenzi e-mailem po nákupu. Když se objednávka přepne na **Dokončená**, naplánuje se přes Action Scheduler WooCommerce e-mail za nastavený počet dní (výchozí 6). V e-mailu je seznam koupených produktů a u každého tlačítko **Napsat hodnocení**, které otevře záložku recenzí na stránce produktu.

## Nastavení

**WooCommerce → Nastavení → E-maily → Žádost o recenzi:** zapnutí, předmět, nadpis, doplňující text a počet dní. Vzhled je stejný jako u ostatních e-mailů WooCommerce.

Aby zákazník mohl recenzi napsat:

- WooCommerce → Nastavení → Produkty: zapnout recenze, štítek „ověřený vlastník“, hvězdičkové hodnocení povinné.
- Nastavení → Diskuze: vypnout „Uživatelé musí být registrováni“, aby šlo hodnotit bez účtu. Ověřený nákup WooCommerce pozná podle e-mailu.

## Chování

- Každá objednávka dostane žádost nejvýš jednou, i když se na Dokončená přepne znovu.
- Zrušená nebo vrácená objednávka žádost nedostane.
- Do objednávky se zapíše poznámka o naplánování i odeslání.
- Naplánované e-maily jsou vidět v Nástroje → Naplánované akce (skupina `velrion-review-request`).

Recenze se zobrazují u produktu a WooCommerce je přidává do strukturovaných dat produktu (hodnocení a hvězdičky ve výsledcích Googlu).
